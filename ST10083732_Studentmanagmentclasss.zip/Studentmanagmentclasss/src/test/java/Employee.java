

import java.io.PrintStream;
import java.util.Scanner;
public class Employee {
private final String name;
private final int id;
public Employee(String n, int i){
    name = n;
    id = i;
}
public String getName(){
    return name;
}
 public int getId(){
     return id;
 }
    public static void main(String[] args) {
       System.out.println("How many employees do want to process their details");
       Scanner input = new Scanner(System.in);
       int number = input.nextInt();
       Payment [] emp = new Payment[number];
       System.out.println("Enter the details for 10 employees");
       for(int i=0; i<number; i++){
           System.out.println("Employee "+(i+1));
           System.out.println("Enter employee id");
           int id = input.nextInt();
           System.out.println("Enter employee name");
           String name = input.next();
           System.out.println("Enter employee salary");
           float sal = input.nextFloat();
           
           emp[i] = new Payment(sal, name, id);
       }
       System.out.println("\nThe employees details are:\n\n");
       for(int i=0; i<number; i++){
           System.out.println("Employee "+(i+1));
           emp[i].display();
       }
    }
}
class Payment extends Employee{
    private final float salary;
   
    Payment(float sal, String n, int i){
        super(n,i);
        salary = sal; 
    }
    void display(){

System.out.printf("""
                                               Employee Name: \t%s
                                                Employee ID:\t%d
                                                Employee Salary %f """, getName(),getId(),getSalary());
    }
    public float getSalary(){
        return salary;
    }
}