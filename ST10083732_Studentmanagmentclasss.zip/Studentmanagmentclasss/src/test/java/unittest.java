
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class Student {
    private int id;
    private String name;
    private int age;
    private final String email;
    private final String course;

    // Constructors
    public Student(int id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    // Getters and setters
    // ... Define getters and setters for each attribute
    
   

public class StudentManagerTest {
    
    public void testDisplayStudentDetails() {
        Student student = new Student(1, "Alice", 20, "alice@example.com", "Math");
       
        
        // Redirect console output to capture it for testing
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        
    
        // Assert expected output

      
    }
}
}